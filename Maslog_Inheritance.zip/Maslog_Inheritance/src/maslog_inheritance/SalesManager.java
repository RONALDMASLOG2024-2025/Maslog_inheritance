/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maslog_inheritance;
import java.sql.*;
import java.util.Scanner;

/**
 *
 * @author Students Account
 */
public class SalesManager extends SalesPerson implements manage{
    
    private Scanner sc = new Scanner(System.in);
    private String sqlSatement;
    
    public SalesManager(int id){
        super(id);
    }

    @Override
    public void authorize() {

        int orderID;
        System.out.println("Enter Order ID to authorize order transaction: ");
        orderID = sc.nextInt();
        
        
        
        sqlSatement = "Update orders set status=? where orderID=?";
        
        try{
          Connection conn = DbaseConnection.getConnection();
          
            PreparedStatement sqlquery = conn.prepareStatement(sqlStatement);
            sqlquery.setInt(1,1);
            
            sqlquery.setInt(2, orderID);
            sqlquery.execute();
            
            
            System.out.println("Order has been authorized");
            
        }catch (SQLException ex){
            System.out.println("Error in Updating");
        }
    }
    
    
    
}
