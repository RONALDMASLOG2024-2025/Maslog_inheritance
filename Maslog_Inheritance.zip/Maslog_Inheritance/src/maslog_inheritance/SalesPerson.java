/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maslog_inheritance;

import java.sql.*;
import java.util.Scanner;

/**
 *
 * @author Students Account
 */
public class SalesPerson extends employee {

    String sqlStatement;
    Scanner sc = new Scanner(System.in);

    public SalesPerson(int id) {
        super(id);
    }

    public boolean hasFurnitureID(int id) {
        try {
            Connection conn = DbaseConnection.getConnection();
            sqlStatement = "Select * from furnituresample where furID = '" + id + "'";
            PreparedStatement sqlquery = conn.prepareStatement(sqlStatement);
            ResultSet result = sqlquery.executeQuery();

            while (result.next()) {
                if (result.getInt("furID") == id) {
                    return true;
                }
            }

        } catch (SQLException ex) {
            System.out.println("Error in retrieving");
        }

        return false;
    }

    public boolean getStock(int furID, int quantity) {

        try {
            Connection conn = DbaseConnection.getConnection();
            sqlStatement = "Select quantity from furnituresample where furID = '" + furID + "'";
            PreparedStatement sqlquery = conn.prepareStatement(sqlStatement);
            ResultSet result = sqlquery.executeQuery();

            if (quantity > result.getInt("quantity") || result.getInt("quantity") == 0) {
                return true;
            }

        } catch (SQLException ex) {
            System.out.println("Error in retrieving the stock");
        }

        return false;
    }

    public void takeOrder() throws SQLException {
        Double Price = 0.0, cost = 0.0;
        int furID, quantity;
        Connection conn = DbaseConnection.getConnection();

        System.out.println("Enter furniture ID to order: ");
        furID = sc.nextInt();

        if (hasFurnitureID(furID)) {
            System.out.println("NAAY ID");

            System.out.println("Enter the quantity: ");
            quantity = sc.nextInt();
            
            if(getStock(furID, quantity)){
                
            }else{
                System.out.println("Insufficient stocks");
            }

            try {
                sqlStatement = "Select Price from furnituresample where furID = '" + furID + "'";
                PreparedStatement sqlquery2 = conn.prepareStatement(sqlStatement);
                ResultSet result1 = sqlquery2.executeQuery();

                while (result1.next()) {
                    Price = result1.getDouble("Price");
                }

                cost = quantity * Price;
            } catch (SQLException ex) {
                System.out.println("Error in retrieving");
            }

        } else {
            System.out.println("Furniture ID does not exist");
            return;
        }

//
//        try {
//            sqlStatement = "INSERT INTO orders (furnitureID, quantity, totalCost, status)" + "VALUES ('" + furID + "','" + quantity + "','" + cost + "','" + 0 + "')";
//            PreparedStatement sqlquery3 = conn.prepareStatement(sqlStatement);
//            sqlquery3.execute();
//            System.out.println("Records have been saved");
//        } catch (SQLException ex) {
//            System.out.println("Error in saving");
//        }
//        try {
//                    sqlStatement = "Select Price from furnituresample where furID = '" + furID + "'";
//                    PreparedStatement sqlquery2 = conn.prepareStatement(sqlStatement);
//                    ResultSet result1 = sqlquery2.executeQuery();
//
//                    while (result.next()) {
//                        Price = result.getDouble("Price");
//                    }
//
//                    cost = quantity * Price;
//                } catch (SQLException ex) {
//                    System.out.println("Error in retrieving");
//                }
//
//                try {
//                    sqlStatement = "INSERT INTO orders (furnitureID, quantity, totalCost, status)" + "VALUES ('" + furID + "','" + quantity + "','" + cost + "','" + 0 + "')";
//                    PreparedStatement sqlquery3 = conn.prepareStatement(sqlStatement);
//                    sqlquery3.execute();
//                    System.out.println("Records have been saved");
//                } catch (SQLException ex) {
//                    System.out.println("Error in saving");
//                }
    }

}
