/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maslog_midmp;

import java.sql.*;
import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author Students Account
 */
public class employee {

    private int id;
    private String name;
    private String sqlStatement;

    public employee(int id) {
        this.id = id;
    }

    public String getName() throws SQLException {

      
        sqlStatement = "Select Name from employee where ID = '" + id + "'";

        try {
            PreparedStatement sqlquery = DbaseConnection.getConnection().prepareStatement(sqlStatement);
            ResultSet result = sqlquery.executeQuery();
            while (result.next()) {
                name = result.getString("Name");
            }
        } catch (SQLException ex) {
            System.out.println("Error in retrieving");
        }

        return name;
    }

}

