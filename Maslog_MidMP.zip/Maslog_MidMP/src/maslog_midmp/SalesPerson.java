/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maslog_midmp;

import java.sql.*;
import java.util.Scanner;

/**
 *
 * @author Students Account
 */
public class SalesPerson extends employee {

    String sqlStatement;
    Scanner sc = new Scanner(System.in);

    public SalesPerson(int id) {
        super(id);
    }

    public boolean hasFurnitureID(int id) {
        try {
            Connection conn = DbaseConnection.getConnection();
            sqlStatement = "Select * from furnituresample where furID = '" + id + "'";
            PreparedStatement sqlquery = conn.prepareStatement(sqlStatement);
            ResultSet result = sqlquery.executeQuery();

            while (result.next()) {
                if (result.getInt("furID") == id) {
                    return true;
                }
            }

        } catch (SQLException ex) {
            System.out.println("Error in retrieving");
        }

        return false;
    }

    public boolean hasStock(int furID, int quantity) {

        try {
            Connection conn = DbaseConnection.getConnection();
            sqlStatement = "Select quantity from furnituresample where furID = '" + furID + "'";
            PreparedStatement sqlquery = conn.prepareStatement(sqlStatement);
            ResultSet result = sqlquery.executeQuery();

            if (result.next()) {

                int x = result.getInt("quantity");

                if (quantity <= x && quantity != 0) {
                    return true;
                }

            }

        } catch (SQLException ex) {
            System.out.println("Error in retrieving the stock");
        }

        return false;
    }

    public void takeOrder() throws SQLException {
        Double Price = 0.0, cost = 0.0;
        int furID, quantity;
        Connection conn = DbaseConnection.getConnection();

        System.out.println("Enter furniture ID to order: ");
        furID = sc.nextInt();

        if (hasFurnitureID(furID)) {

            System.out.println("Enter the quantity: ");
            quantity = sc.nextInt();

            if (hasStock(furID, quantity)) {

                try {
                    sqlStatement = "Select Price from furnituresample where furID = '" + furID + "'";
                    PreparedStatement sqlquery1 = conn.prepareStatement(sqlStatement);
                    ResultSet result = sqlquery1.executeQuery();

                    while (result.next()) {
                        Price = result.getDouble("Price");
                    }

                    cost = quantity * Price;
                } catch (SQLException ex) {
                    System.out.println("Error in retrieving");
                }

                try {
                    sqlStatement = "INSERT INTO orders (furnitureID, quantity, totalCost, status)" + "VALUES ('" + furID + "','" + quantity + "','" + cost + "','" + 0 + "')";
                    PreparedStatement sqlquery2 = conn.prepareStatement(sqlStatement);
                    sqlquery2.execute();
                    System.out.println("Records have been saved");
                } catch (SQLException ex) {
                    System.out.println("Error in saving");
                }
            } else {
                System.out.println("Insufficient stocks");
            }

        } else {
            System.out.println("Furniture ID does not exist");
            return;
        }

    }

}
