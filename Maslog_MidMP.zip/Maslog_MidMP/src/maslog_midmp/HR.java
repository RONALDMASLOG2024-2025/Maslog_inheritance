/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maslog_midmp;

import java.sql.*;
import java.util.Scanner;

/**
 *
 * @author Ronald
 */
public class HR {

    private static String sqlStatement;
    Scanner sc = new Scanner(System.in);

    public void getEmployee() throws SQLException {

        System.out.print("\nEnter the ID of the Employee: ");
        int id = sc.nextInt();

        employee emp = new employee(id);
        String name = emp.getName();

        if (name != null) {
            System.out.println("Employee: " + name);
        }else{
            System.out.println("No employee found with the ID: " + id);
        }
        return;
    }

    public void createEmployee() {

        String name;
        double salary;
        double commision;
        String position;

        System.out.println("\nAdd new Employee");
        System.out.print("Enter name: ");

        name = sc.next();

        System.out.print("Enter Postion: ");
        position = sc.next();
        System.out.print("Enter Salary: ");
        salary = sc.nextDouble();
        System.out.print("Enter Commision: ");
        commision = sc.nextDouble();

        try {

            Connection conn = DbaseConnection.getConnection();
            sqlStatement = "INSERT INTO `employee` (`Name`, `salary`, `commision`, `Position`) VALUES ('" + name + " ', '" + salary + "', '" + commision + "', '" + position + "')";
            // sqlStatement = "INSERT INTO orders (furnitureID, quantity, totalCost, status)" + "VALUES ('" + furID + "','" + quantity + "','" + cost + "','" + 0 + "')";
            PreparedStatement sqlquery2 = conn.prepareStatement(sqlStatement);
            sqlquery2.execute();
            System.out.println("Records have been saved");

        } catch (SQLException ex) {
            System.out.println("Error in saving");
        }

        return;
    }

}
