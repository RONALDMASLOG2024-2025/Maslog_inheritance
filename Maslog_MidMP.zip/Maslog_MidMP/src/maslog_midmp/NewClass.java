package maslog_midmp;

import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author Ronald Maslog
 */
public class NewClass {

    public static void main(String[] args) throws SQLException {

        int id;
        char option;
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter an ID: ");
        id = sc.nextInt();

        SalesManager x = new SalesManager(id);
        System.out.println("Good day " + x.getName());

        HR emp = new HR();

        for (;;) {
            System.out.println("[T]ake Order\t[A]uthorized order\t[M]anage Employee\t[G]et Employee\t[E]xit");
            System.out.print("Select Operation: ");
            option = sc.next().charAt(0);
            if (option == 'T' || option == 't') {
                x.takeOrder();
            } else if (option == 'A' || option == 'a') {
                x.authorize();
            } else if (option == 'E' || option == 'e') {
                System.exit(0);
            } else if (option == 'M' || option == 'm') {
                emp.createEmployee();
            }  else if (option == 'G' || option == 'g') {
                emp.getEmployee();
            } else {
                System.out.println("Invalid Option");
            }
        }

    }

}
