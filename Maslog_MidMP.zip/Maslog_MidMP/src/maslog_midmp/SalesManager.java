/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maslog_midmp;

import java.sql.*;
import java.util.Scanner;

/**
 *
 * @author Students Account
 */
public class SalesManager extends SalesPerson implements manage {

    private Scanner sc = new Scanner(System.in);
    private String sqlSatement;

    public SalesManager(int id) {
        super(id);
    }

    public void authorize() {

        int orderID;
        System.out.println("Enter Order ID to authorize order transaction: ");

        orderID = sc.nextInt();

        sqlStatement = "Update orders set status=? where orderID=?";

        try {
            Connection conn = DbaseConnection.getConnection();
            PreparedStatement sqlquery = conn.prepareStatement(sqlStatement);
            sqlquery.setInt(1, 1);

            sqlquery.setInt(2, orderID);
            sqlquery.executeUpdate();
            System.out.println("Order has been authorized");
        } catch (SQLException ex) {
            System.out.println("Error in Updating");
        }

    }

//    @Override
//    public void authorize() {
//
//        int orderID;
//        System.out.println("Enter Order ID to authorize order transaction: ");
//        orderID = sc.nextInt();
//        System.out.println("");
//
//        try {
//            Connection conn = DbaseConnection.getConnection();
//            sqlSatement = "Update orders set status='1' where orderID=1'" + orderID + "'";
//            sqlSatement = "Updte orders set status = ? where orderID=?";
////            sqlSatement = "UPDATE `orders` SET `status` = '1' WHERE `orders`.`orderID` = 19";
//            PreparedStatement sqlquery = conn.prepareStatement(sqlStatement);
//            sqlquery.setInt(1,1);
//            
//            sqlquery.setInt(2, orderID);
//            sqlquery.executeUpdate();
//
//            System.out.println("Order has been authorized");
//
//        } catch (SQLException ex) {
//            System.out.println("Error in Updating");
//        }
//    }
}
